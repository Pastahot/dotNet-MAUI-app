using System.Collections.ObjectModel;

namespace finalemore
{
    public class ProfileListViewModel : BaseViewModel
    {
        public ObservableCollection<Profile> Profiles { get; set; }

        public ProfileListViewModel()
        {
            Profiles = new ObservableCollection<Profile>();
            LoadProfiles();
        }

        public void LoadProfiles()
        {
            Profiles.Add(new Profile { Id = "1", Name = "   Peto Cmorik    ", ImageUrl = "https://fastly.picsum.photos/id/1/50/50.jpg?hmac=uD_AuvYRKIjw0o41oBnGz4vODQQKOL4EuhDQbxl26Ys", Bio = "   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book   " });
            Profiles.Add(new Profile { Id = "2", Name = "   Adam Tak�   ", ImageUrl = "https://fastly.picsum.photos/id/177/50/50.jpg?hmac=PdLLhdrQ7RIL34FxSbBLGvmgA_CpmUop1GoqrxQzqD0", Bio = " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book    " });
            Profiles.Add(new Profile { Id = "3", Name = "   Jozef Pepo  ", ImageUrl = "https://fastly.picsum.photos/id/257/50/50.jpg?hmac=GdpsPKjr8fcB4Gsc3vDMCzxQlrXu5bs2I0faiXRAL9Q", Bio = " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book    " });
            Profiles.Add(new Profile { Id = "4", Name = "   Lucia Hentak�    ", ImageUrl = "https://fastly.picsum.photos/id/826/50/50.jpg?hmac=_vlLH89riKFmnZqdJ6ZX6SFm1iyb5ChyKSkKWSf5fes", Bio = " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book    " });
            Profiles.Add(new Profile { Id = "5", Name = "   Tereza Onak�   ", ImageUrl = "https://fastly.picsum.photos/id/794/50/50.jpg?hmac=0q9WbCbR61bYJtvvCKBhp5DJKWJMTGDAcDrWOBQgrE0", Bio = " Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book    " });
        }
    }
}
