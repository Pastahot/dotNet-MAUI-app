namespace finalemore
{
    public class ProfileDetailViewModel : BaseViewModel
    {
        public string Title { get; }
        public Profile Profile { get; set; }

        public ProfileDetailViewModel(Profile profile = null)
        {
            Title = profile?.Name;
            Profile = profile;
        }
    }
}
