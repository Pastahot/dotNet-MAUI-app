﻿using Microsoft.Maui.Controls;
using System.Linq;

namespace finalemore.Views
{
    public partial class ProfileListPage : ContentPage
    {
        public ProfileListPage()
        {
            InitializeComponent();
            BindingContext = new ProfileListViewModel();
        }

        public void OnProfileSelected(object sender, SelectionChangedEventArgs args)
        {
            var profile = args.CurrentSelection.FirstOrDefault() as Profile;
            if (profile == null)
                return;

            Navigation.PushAsync(new ProfileDetailPage(new ProfileDetailViewModel(profile)));

            
            ProfilesCollectionView.SelectedItem = null;
        }
    }
}
