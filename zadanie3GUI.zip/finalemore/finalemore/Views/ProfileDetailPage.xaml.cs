﻿using Microsoft.Maui.Controls;

namespace finalemore
{
    public partial class ProfileDetailPage : ContentPage
    {
        ProfileDetailViewModel viewModel;

        public ProfileDetailPage(ProfileDetailViewModel viewModel)
        {
            InitializeComponent();
            BindingContext = this.viewModel = viewModel;
        }

        public void OnBackButtonClicked(object sender, EventArgs e)
        {
            Navigation.PopAsync();
        }
    }
}
